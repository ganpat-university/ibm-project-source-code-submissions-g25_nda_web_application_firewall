import subprocess

p = subprocess.Popen(["bash","iptable-sgn.sh","1","192.168.1.72"])